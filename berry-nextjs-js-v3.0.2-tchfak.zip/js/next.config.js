// eslint-disable-next-line no-undef
module.exports = {
  reactStrictMode: true,
}
