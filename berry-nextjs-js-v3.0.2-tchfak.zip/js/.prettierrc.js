module.exports = {
    bracketSpacing: true,
    printWidth: 140,
    singleQuote: true,
    trailingComma: 'none',
    tabWidth: 4,
    useTabs: false,
    endOfLine: 'auto'
};
